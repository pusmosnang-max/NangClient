# Building NangClient with GitHub Codespaces

You don't need to install Java or IntelliJ on your own computer for
this path — everything compiles in the cloud. You'll still need
Minecraft itself installed locally to actually *play* with the mod
(see Step 5).

## Step 1 — Get the base project into a GitHub repo

1. Go to **https://fabricmc.net/develop/template/**, generate the base
   project (Minecraft `1.20.1`, mod name `NangClient`, mod ID
   `nangclient`, package `net.nangclient`, language Java) and download it.
2. Create a new empty repo on GitHub (e.g. `nangclient-mod`).
3. Copy in all the files from that generated zip, then copy the files
   from **this** folder on top — including the hidden `.devcontainer`
   folder — overwriting `fabric.mod.json` and deleting the example
   `Nangclient*.java` classes as described in the main `README.md`.
4. Push all of it to your new GitHub repo (via GitHub Desktop, or
   GitHub's "upload files" web UI if you'd rather not use git commands).

## Step 2 — Open it in a Codespace

1. On your repo's GitHub page, click the green **Code** button →
   **Codespaces** tab → **Create codespace on main**.
2. Wait ~1–2 minutes for it to build the container (it installs Java 17
   automatically from the `.devcontainer` config I included).

## Step 3 — Build the mod

In the Codespace's built-in terminal (bottom panel), run:

```bash
./gradlew build
```

The first run takes a few minutes — it's downloading Minecraft's code,
Fabric, and mappings, same as the IntelliJ path would. Network access
in Codespaces is fine for this (unlike some sandboxed environments).

If it finishes with `BUILD SUCCESSFUL`, your mod file is at:

```
build/libs/nangclient-0.1.0.jar
```

## Step 4 — Check your work without a display

You can't launch the actual game here, but you can still catch real
problems:

```bash
./gradlew build          # full compile + packaging — catches most errors
./gradlew compileJava     # faster, Java-only compile check while iterating
```

Read any error output top-to-bottom — the first error is usually the
real one; later ones are often just knock-on effects of it.

## Step 5 — Download the jar and actually play

1. In the Codespace's file explorer (left sidebar), find
   `build/libs/nangclient-0.1.0.jar`, right-click → **Download**.
2. On your own computer, install **Fabric Loader** normally via the
   installer at fabricmc.net (this needs a real Minecraft install).
3. Download **Fabric API** (the library, separate from your mod) from
   Modrinth or CurseForge.
4. Put both `nangclient-0.1.0.jar` and the Fabric API jar into your
   `.minecraft/mods` folder.
5. Add your font file too — remember `nangclient.ttf` needs to be
   *inside the jar* at build time (in
   `src/main/resources/assets/nangclient/font/`), not added after, so
   make sure it's committed to the repo before you build in Step 3.
6. Launch Minecraft through the Fabric profile and press **N** in-game.

## Iterating

Every time you change code in the Codespace: `git commit` + `git push`
(or just re-run `./gradlew build` if you're still in the same session),
then repeat Step 5 to grab the new jar and test locally. There's no
way around this back-and-forth without a local graphical setup — a
cloud container fundamentally can't open a game window for you.
