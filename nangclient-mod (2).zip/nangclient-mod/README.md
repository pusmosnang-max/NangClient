# NangClient — Performance Tweaks Mod (Fabric)

A small Fabric mod for Minecraft 1.20.1 with client-side performance
toggles. This is a legitimate FPS mod, not a cheat client — it only
touches rendering settings (particles, clouds, fog, shadows), nothing
that gives combat/movement advantages.

You don't need to know how to code to get this running. Follow the
steps below exactly. It'll take about 20–30 minutes the first time.

## What you'll install (all free)

1. **Java Development Kit 17** — https://adoptium.net (pick "Temurin 17", your OS)
2. **IntelliJ IDEA Community Edition** — https://www.jetbrains.com/idea/download (free version, scroll down)
3. That's it — the mod project itself handles downloading Minecraft/Fabric automatically.

## Step 1 — Generate the base project

Fabric provides an official project generator so everyone starts from
working, up-to-date files (their exact version numbers change often,
so this avoids using stale ones):

1. Go to **https://fabricmc.net/develop/template/**
2. Fill in:
   - Minecraft version: **1.20.1** (or leave it default/latest — just note whichever you pick)
   - Mod name: `NangClient`
   - Mod ID: `nangclient`
   - Package name: `net.nangclient`
   - Language: **Java**
   - Split client/common sources: **No** (keep unchecked)
3. Click **Generate Zip**, download it, and unzip it somewhere like `Documents/nangclient-mod`.

## Step 2 — Replace the example files with the real ones

The generated project comes with placeholder "example mod" files.
Delete these from the generated project:
- `src/main/java/net/nangclient/NangclientMod.java` (or similarly named example class)
- `src/main/java/net/nangclient/NangclientClient.java` (example client class)
- `src/main/resources/nangclient.mixins.json` (if present and empty)

Then copy in the files I've built for you (from this folder), keeping
the same folder structure:
- `src/main/java/net/nangclient/NangClientMod.java`
- `src/main/java/net/nangclient/NangClientConfig.java`
- `src/main/java/net/nangclient/NangClientClientInit.java`
- `src/main/java/net/nangclient/NangClientConfigScreen.java`
- `src/main/java/net/nangclient/NangClientHud.java`
- `src/main/resources/fabric.mod.json` → **overwrite** the generated one
- `src/main/resources/assets/nangclient/lang/en_us.json` → overwrite/merge
- `src/main/resources/assets/nangclient/font/nangclient.json`
- `src/main/resources/assets/nangclient/font/` folder itself (see Step 2b)

### Step 2b — Add a font file

The mod is wired up to use a custom font, but I can't generate an
actual font file (a `.ttf` is binary image/outline data, not text I
can write). You need to add one yourself:

1. Download any free `.ttf` from **https://fonts.google.com** — good
   picks for a clean UI: "Inter", "Rubik", "JetBrains Mono", or "Press
   Start 2P" for a retro pixel look.
2. Rename the file to exactly `nangclient.ttf`.
3. Put it in `src/main/resources/assets/nangclient/font/nangclient.ttf`
   (next to the `nangclient.json` I already wrote).
4. Delete the `PUT_YOUR_FONT_HERE.txt` placeholder in that folder.

If your font is `.otf` instead of `.ttf`, also open
`nangclient.json` and change `"file": "nangclient:font/nangclient.ttf"`
to end in `.otf`.

## Step 3 — Open and build

1. Open **IntelliJ IDEA** → "Open" → select the unzipped project folder.
2. IntelliJ will detect it's a Gradle project and start downloading
   dependencies automatically (this takes a few minutes the first time —
   it's downloading Minecraft's code, Fabric, and mappings).
3. Once it's done ("Gradle build finished" in the bottom bar), open the
   **Gradle** panel on the right side → `nangclient-mod` → `Tasks` → `fabric` →
   double-click **`runClient`**.
4. Minecraft will launch with your mod loaded. You'll see
   `NangClient performance mod loaded.` in the log window.

## Step 4 — Try it out

1. Press **N** in-game (default key, rebindable in Options → Controls →
   NangClient) to open the NangClient menu.
2. You'll see a clean panel with the title in your custom font and five
   toggle buttons: Reduced Particles, Disable Clouds, Reduced Fog,
   Limited Shadows, and HUD Watermark.
3. Click "Reduced Particles" — this one is fully wired up, so your
   particle detail setting flips between ALL and MINIMAL instantly.
4. If "HUD Watermark" is ON, you'll see a small translucent
   "NangClient" watermark in the bottom-right corner, in your custom
   font, whenever the HUD is visible (hidden automatically if you
   press F1 to hide the vanilla HUD).

The clouds/fog/shadows buttons save their state (and you'll see the
label flip ON/OFF), but aren't wired to real rendering changes yet —
see "Next steps" below for how to finish those.

## Step 5 — Get a shareable .jar file

Once you're happy with it: in the Gradle panel, run **`build`** instead
of `runClient`. Your mod file will appear at:
`build/libs/nangclient-0.1.0.jar`

To use it: install **Fabric Loader** normally (via the Fabric installer
at fabricmc.net), then drop that `.jar` into your `.minecraft/mods`
folder along with **Fabric API** (download separately from Modrinth/CurseForge).

## Next steps (once you're comfortable)

The particle toggle uses a real, stable Minecraft option, so it was
safe for me to write exactly. The clouds/fog/shadows toggles need a
**Mixin** — code that reaches into Minecraft's own rendering classes —
and the exact method names depend on your Minecraft version and can
change between versions, so I didn't want to hand you code that might
silently fail to compile.

To add one yourself once the base mod is running:
1. In IntelliJ, install the **"Minecraft Development"** plugin
   (Settings → Plugins → Marketplace → search it) — it lets you jump
   straight to Minecraft's decompiled source.
2. Find `WorldRenderer` in the project, look for a method with "cloud"
   or "fog" in the name.
3. Create a Mixin class targeting that method and `@Inject` at `HEAD`
   with `cancellable = true`, then call `ci.cancel()` when
   `NangClientClientInit.CONFIG.disableClouds` is true.

I'm happy to write that Mixin with you once you've got this base
version running and can tell me your exact Minecraft version — that
way I can guide you to the right method name instead of guessing.
