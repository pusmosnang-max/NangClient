package net.nangclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/**
 * Draws a small, low-opacity "NangClient" watermark in the bottom-right
 * corner, in the custom font, whenever config.showHud is true.
 *
 * NOTE ON VERSIONS: HudRenderCallback's method signature has changed
 * between Minecraft versions (this one targets 1.20.1's Fabric API —
 * `onHudRender(DrawContext, float)`). If you update to a newer
 * Minecraft version and this fails to compile, check Fabric API's
 * current HudRenderCallback signature and adjust the method below —
 * IntelliJ's autocomplete on `HudRenderCallback.EVENT.register(` will
 * show you the exact expected signature for your version.
 */
public class NangClientHud {

    public static void register() {
        HudRenderCallback.EVENT.register(NangClientHud::onHudRender);
    }

    private static void onHudRender(DrawContext context, float tickDelta) {
        NangClientConfig cfg = NangClientClientInit.CONFIG;
        if (cfg == null || !cfg.showHud) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return; // respect vanilla F1 hide-HUD

        Text watermark = Text.literal("NangClient")
                .setStyle(Style.EMPTY.withFont(NangClientMod.FONT).withColor(0x80FFFFFF));

        int textWidth = client.textRenderer.getWidth(watermark);
        int x = context.getScaledWindowWidth() - textWidth - 4;
        int y = context.getScaledWindowHeight() - 12;

        context.drawTextWithShadow(client.textRenderer, watermark, x, y, 0x80FFFFFF);
    }
}
