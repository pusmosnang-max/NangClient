package net.nangclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/**
 * NangClient's settings menu. Plain vanilla widgets (no extra UI
 * library needed) laid out on a simple rounded panel, with the title
 * rendered in the custom font.
 *
 * Open it in-game with the "N" key (rebindable in Controls > NangClient).
 */
public class NangClientConfigScreen extends Screen {

    // If opened from the pause menu, this is the screen to return to.
    // If opened with the hotkey mid-game, this is null (closes to gameplay).
    private final Screen parent;

    // Panel size — tweak these if you add more rows.
    private static final int PANEL_WIDTH = 220;
    private static final int ROW_HEIGHT = 24;
    private static final int ROW_SPACING = 4;

    protected NangClientConfigScreen(Screen parent) {
        super(Text.translatable("screen.nangclient.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        NangClientConfig cfg = NangClientClientInit.CONFIG;

        int panelHeight = 30 + (ROW_HEIGHT + ROW_SPACING) * 5 + 30;
        int left = (this.width - PANEL_WIDTH) / 2;
        int top = (this.height - panelHeight) / 2;
        int y = top + 34;

        // --- Reduced particles (the one toggle that's actually wired up) ---
        this.addDrawableChild(toggleButton(left, y, "reduceParticles", cfg.reduceParticles, value -> {
            cfg.reduceParticles = value;
            cfg.save();
            NangClientClientInit.applyParticleSetting(value);
        }));
        y += ROW_HEIGHT + ROW_SPACING;

        // --- Clouds / fog / shadows: saved to config, rendering hook is a
        // "next step" (see README) — the button still works, it just
        // doesn't change anything visually yet until that Mixin is added.
        this.addDrawableChild(toggleButton(left, y, "disableClouds", cfg.disableClouds, value -> {
            cfg.disableClouds = value;
            cfg.save();
        }));
        y += ROW_HEIGHT + ROW_SPACING;

        this.addDrawableChild(toggleButton(left, y, "reduceFog", cfg.reduceFog, value -> {
            cfg.reduceFog = value;
            cfg.save();
        }));
        y += ROW_HEIGHT + ROW_SPACING;

        this.addDrawableChild(toggleButton(left, y, "limitEntityShadows", cfg.limitEntityShadows, value -> {
            cfg.limitEntityShadows = value;
            cfg.save();
        }));
        y += ROW_HEIGHT + ROW_SPACING;

        this.addDrawableChild(toggleButton(left, y, "showHud", cfg.showHud, value -> {
            cfg.showHud = value;
            cfg.save();
        }));
        y += ROW_HEIGHT + ROW_SPACING + 6;

        // --- Done button, closes back to whatever screen we came from ---
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> this.close())
                .dimensions(left, y, PANEL_WIDTH, 20)
                .build());
    }

    // Builds one on/off row. `key` is used to look up the button's label
    // from the lang file (e.g. "option.nangclient.reduceParticles").
    private ButtonWidget toggleButton(int x, int y, String key, boolean initialValue, java.util.function.Consumer<Boolean> onToggle) {
        return ButtonWidget.builder(labelFor(key, initialValue), b -> {
            boolean newValue = !labelSaysOn(b.getMessage());
            onToggle.accept(newValue);
            b.setMessage(labelFor(key, newValue));
        }).dimensions(x, y, PANEL_WIDTH, ROW_HEIGHT - 4).build();
    }

    private Text labelFor(String key, boolean on) {
        return Text.translatable("option.nangclient." + key)
                .append(Text.literal(": " + (on ? "ON" : "OFF")));
    }

    private boolean labelSaysOn(Text current) {
        return current.getString().endsWith("ON");
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dim the game behind the menu.
        this.renderBackground(context, mouseX, mouseY, delta);

        int panelHeight = 30 + (ROW_HEIGHT + ROW_SPACING) * 5 + 30;
        int left = (this.width - PANEL_WIDTH) / 2;
        int top = (this.height - panelHeight) / 2;

        // Simple clean panel: soft fill + a subtle border, no texture needed.
        int fillColor = 0xCC101014;   // translucent near-black
        int borderColor = 0xFF3A6FF7; // accent color for the border/title

        context.fill(left - 10, top - 10, left + PANEL_WIDTH + 10, top + panelHeight + 10, fillColor);
        drawBorder(context, left - 10, top - 10, PANEL_WIDTH + 20, panelHeight + 20, borderColor);

        // Title, rendered in the custom font.
        Text title = Text.translatable("screen.nangclient.title")
                .copy()
                .setStyle(Style.EMPTY.withFont(NangClientMod.FONT).withColor(0xFFFFFF));
        context.drawCenteredTextWithShadow(this.textRenderer, title, this.width / 2, top + 6, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    // DrawContext has a filled-rect helper but not an outline one on every
    // version, so draw a 1px border out of four thin fills — always works.
    private void drawBorder(DrawContext context, int x, int y, int w, int h, int color) {
        context.fill(x, y, x + w, y + 1, color);             // top
        context.fill(x, y + h - 1, x + w, y + h, color);      // bottom
        context.fill(x, y, x + 1, y + h, color);              // left
        context.fill(x + w - 1, y, x + w, y + h, color);      // right
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }

    @Override
    public boolean shouldPause() {
        return false; // don't pause singleplayer just for opening this menu
    }
}
