package net.nangclient;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main mod entry point. Fabric calls onInitialize() when the game
 * (client OR a dedicated server) starts up.
 *
 * This mod itself doesn't do much here — the actual performance
 * tweaks live in NangClientClientInit, because they only make sense
 * on the client (a server has no screen to render).
 */
public class NangClientMod implements ModInitializer {

    // A shared ID for this mod, used for logging and for the config file name.
    public static final String MOD_ID = "nangclient";

    // A logger you can use anywhere: NangClientMod.LOGGER.info("message");
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Points at assets/nangclient/font/nangclient.json — pass this to
    // Style.withFont(...) anywhere you want to render with the custom font.
    public static final Identifier FONT = Identifier.of(MOD_ID, MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("NangClient performance mod loaded.");
    }
}
