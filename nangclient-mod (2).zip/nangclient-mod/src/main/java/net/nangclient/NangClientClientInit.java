package net.nangclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesOption;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Client-side setup. Registers one keybind (default: N) that opens
 * NangClient's own settings menu, where every toggle lives.
 */
public class NangClientClientInit implements ClientModInitializer {

    // Holds the loaded/saved settings for the whole session.
    // Other classes (the screen, the HUD) read/write this directly.
    public static NangClientConfig CONFIG;

    private KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        CONFIG = NangClientConfig.load();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nangclient.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_N, // default key: N. Player can rebind in Controls > NangClient.
                "category.nangclient"
        ));

        // Apply the saved particle setting immediately on startup, so it
        // takes effect even before the player opens the menu this session.
        applyParticleSetting(CONFIG.reduceParticles);

        // Draws the small corner watermark every frame, when enabled.
        NangClientHud.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new NangClientConfigScreen(null));
                }
            }
        });

        NangClientMod.LOGGER.info("NangClient client-side setup complete.");
    }

    // This is the ONE optimization wired to a real, stable vanilla API:
    // Minecraft already has a built-in particle detail option (ALL /
    // DECREASED / MINIMAL). The config screen calls this whenever the
    // particle toggle button is clicked.
    static void applyParticleSetting(boolean reduce) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;
        client.options.getParticlesOption().setValue(
                reduce ? ParticlesOption.MINIMAL : ParticlesOption.ALL
        );
    }
}
