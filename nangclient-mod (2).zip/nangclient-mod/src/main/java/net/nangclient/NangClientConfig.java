package net.nangclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Holds every performance toggle. Values here are saved to
 * <minecraft folder>/config/nangclient.json so your settings
 * persist between sessions.
 *
 * Each field is a simple on/off switch. Turning something "off"
 * here means "reduce or skip this expensive visual effect".
 */
public class NangClientConfig {

    // ---- toggles you can flip in-game with keybinds (see NangClientClientInit) ----
    public boolean reduceParticles = true;   // fewer particles (smoke, splashes, etc.)
    public boolean disableClouds = true;     // clouds are surprisingly expensive to render
    public boolean reduceFog = true;         // cuts down fog rendering distance/work
    public boolean limitEntityShadows = true; // simplifies entity shadow rendering
    public boolean showHud = true;            // small corner watermark showing the mod is active

    // ---- internal: where the config file lives ----
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve(NangClientMod.MOD_ID + ".json");
    }

    /** Load config from disk, or create a fresh one with defaults if none exists yet. */
    public static NangClientConfig load() {
        Path path = configPath();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                NangClientConfig loaded = GSON.fromJson(reader, NangClientConfig.class);
                if (loaded != null) return loaded;
            } catch (IOException e) {
                NangClientMod.LOGGER.warn("Could not read nangclient.json, using defaults", e);
            }
        }
        NangClientConfig fresh = new NangClientConfig();
        fresh.save();
        return fresh;
    }

    /** Write the current settings back to disk. Call this whenever a toggle changes. */
    public void save() {
        try {
            Files.createDirectories(configPath().getParent());
            try (Writer writer = Files.newBufferedWriter(configPath(), StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            NangClientMod.LOGGER.warn("Could not save nangclient.json", e);
        }
    }
}
